# Regression
## Metro Interstate Traffic Volume

This data set contains Hourly weather features and holidays included for impacts on traffic volume..The main objective is to clean the data and fit it with a regression model to predict the traffic volume.
